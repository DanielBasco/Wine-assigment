# Wine assignment | Asger and Daniel


```python
# Imports
import pandas as pd
import numpy as np
from scipy import stats
from scipy.stats import pearsonr, spearmanr, kendalltau
import seaborn as sbn
```


```python
# Read the files
# header=1 is added because the original header was Unnamed
red_df = pd.read_excel("winequality-red.xlsx", header=1)
white_df = pd.read_excel("winequality-white.xlsx", header=1)
```



## Hypothesis and expectations

* H0 = Our hypothesis is the alcohol average for red and white wine are the same.
* H1 = Alternative hypothesis is one wine has a higher alcohol average.

## 1) Start Exploration of red wine 


```python
#Size of dataframe
red_df.shape
```




    (1599, 12)




```python
#Data types and attibute names | no categories
red_df.info()
```

    <class 'pandas.DataFrame'>
    RangeIndex: 1599 entries, 0 to 1598
    Data columns (total 12 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   fixed acidity         1599 non-null   float64
     1   volatile acidity      1599 non-null   float64
     2   citric acid           1599 non-null   float64
     3   residual sugar        1599 non-null   float64
     4   chlorides             1599 non-null   float64
     5   free sulfur dioxide   1599 non-null   float64
     6   total sulfur dioxide  1599 non-null   float64
     7   density               1599 non-null   float64
     8   pH                    1599 non-null   float64
     9   sulphates             1599 non-null   float64
     10  alcohol               1599 non-null   float64
     11  quality               1599 non-null   int64  
    dtypes: float64(11), int64(1)
    memory usage: 150.0 KB
    


```python
# The range, mean, count, quartiles and standard deviations
red_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>8.319637</td>
      <td>0.527821</td>
      <td>0.270976</td>
      <td>2.538806</td>
      <td>0.087467</td>
      <td>15.874922</td>
      <td>46.467792</td>
      <td>0.996747</td>
      <td>3.311113</td>
      <td>0.658149</td>
      <td>10.422983</td>
      <td>5.636023</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.741096</td>
      <td>0.179060</td>
      <td>0.194801</td>
      <td>1.409928</td>
      <td>0.047065</td>
      <td>10.460157</td>
      <td>32.895324</td>
      <td>0.001887</td>
      <td>0.154386</td>
      <td>0.169507</td>
      <td>1.065668</td>
      <td>0.807569</td>
    </tr>
    <tr>
      <th>min</th>
      <td>4.600000</td>
      <td>0.120000</td>
      <td>0.000000</td>
      <td>0.900000</td>
      <td>0.012000</td>
      <td>1.000000</td>
      <td>6.000000</td>
      <td>0.990070</td>
      <td>2.740000</td>
      <td>0.330000</td>
      <td>8.400000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>7.100000</td>
      <td>0.390000</td>
      <td>0.090000</td>
      <td>1.900000</td>
      <td>0.070000</td>
      <td>7.000000</td>
      <td>22.000000</td>
      <td>0.995600</td>
      <td>3.210000</td>
      <td>0.550000</td>
      <td>9.500000</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7.900000</td>
      <td>0.520000</td>
      <td>0.260000</td>
      <td>2.200000</td>
      <td>0.079000</td>
      <td>14.000000</td>
      <td>38.000000</td>
      <td>0.996750</td>
      <td>3.310000</td>
      <td>0.620000</td>
      <td>10.200000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>9.200000</td>
      <td>0.640000</td>
      <td>0.420000</td>
      <td>2.600000</td>
      <td>0.090000</td>
      <td>21.000000</td>
      <td>62.000000</td>
      <td>0.997835</td>
      <td>3.400000</td>
      <td>0.730000</td>
      <td>11.100000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>15.900000</td>
      <td>1.580000</td>
      <td>1.000000</td>
      <td>15.500000</td>
      <td>0.611000</td>
      <td>72.000000</td>
      <td>289.000000</td>
      <td>1.003690</td>
      <td>4.010000</td>
      <td>2.000000</td>
      <td>14.900000</td>
      <td>8.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# The first 5 
red_df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7.4</td>
      <td>0.70</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>7.8</td>
      <td>0.88</td>
      <td>0.00</td>
      <td>2.6</td>
      <td>0.098</td>
      <td>25.0</td>
      <td>67.0</td>
      <td>0.9968</td>
      <td>3.20</td>
      <td>0.68</td>
      <td>9.8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7.8</td>
      <td>0.76</td>
      <td>0.04</td>
      <td>2.3</td>
      <td>0.092</td>
      <td>15.0</td>
      <td>54.0</td>
      <td>0.9970</td>
      <td>3.26</td>
      <td>0.65</td>
      <td>9.8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.2</td>
      <td>0.28</td>
      <td>0.56</td>
      <td>1.9</td>
      <td>0.075</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>0.9980</td>
      <td>3.16</td>
      <td>0.58</td>
      <td>9.8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.4</td>
      <td>0.70</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.9978</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Sample of 5 
red_df.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>527</th>
      <td>7.0</td>
      <td>0.38</td>
      <td>0.49</td>
      <td>2.5</td>
      <td>0.097</td>
      <td>33.0</td>
      <td>85.0</td>
      <td>0.99620</td>
      <td>3.39</td>
      <td>0.77</td>
      <td>11.4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1257</th>
      <td>7.0</td>
      <td>0.58</td>
      <td>0.28</td>
      <td>4.8</td>
      <td>0.085</td>
      <td>12.0</td>
      <td>69.0</td>
      <td>0.99633</td>
      <td>3.32</td>
      <td>0.70</td>
      <td>11.0</td>
      <td>6</td>
    </tr>
    <tr>
      <th>933</th>
      <td>7.4</td>
      <td>0.61</td>
      <td>0.01</td>
      <td>2.0</td>
      <td>0.074</td>
      <td>13.0</td>
      <td>38.0</td>
      <td>0.99748</td>
      <td>3.48</td>
      <td>0.65</td>
      <td>9.8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>599</th>
      <td>12.7</td>
      <td>0.59</td>
      <td>0.45</td>
      <td>2.3</td>
      <td>0.082</td>
      <td>11.0</td>
      <td>22.0</td>
      <td>1.00000</td>
      <td>3.00</td>
      <td>0.70</td>
      <td>9.3</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1579</th>
      <td>6.2</td>
      <td>0.56</td>
      <td>0.09</td>
      <td>1.7</td>
      <td>0.053</td>
      <td>24.0</td>
      <td>32.0</td>
      <td>0.99402</td>
      <td>3.54</td>
      <td>0.60</td>
      <td>11.3</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>



## 1.1) Start Exploration of white wine


```python
# Size of dataframe
white_df.shape
```




    (4898, 12)




```python
# Datatypes and row names | no categories
white_df.info()
```

    <class 'pandas.DataFrame'>
    RangeIndex: 4898 entries, 0 to 4897
    Data columns (total 12 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   fixed acidity         4898 non-null   float64
     1   volatile acidity      4898 non-null   float64
     2   citric acid           4898 non-null   float64
     3   residual sugar        4898 non-null   float64
     4   chlorides             4898 non-null   float64
     5   free sulfur dioxide   4898 non-null   float64
     6   total sulfur dioxide  4898 non-null   float64
     7   density               4898 non-null   float64
     8   pH                    4898 non-null   float64
     9   sulphates             4898 non-null   float64
     10  alcohol               4898 non-null   float64
     11  quality               4898 non-null   int64  
    dtypes: float64(11), int64(1)
    memory usage: 459.3 KB
    


```python
# The range, mean, count, quartiles and standard deviations
white_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
      <td>4898.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>6.854788</td>
      <td>0.278241</td>
      <td>0.334192</td>
      <td>6.391415</td>
      <td>0.045772</td>
      <td>35.308085</td>
      <td>138.360657</td>
      <td>0.994027</td>
      <td>3.188267</td>
      <td>0.489847</td>
      <td>10.514267</td>
      <td>5.877909</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.843868</td>
      <td>0.100795</td>
      <td>0.121020</td>
      <td>5.072058</td>
      <td>0.021848</td>
      <td>17.007137</td>
      <td>42.498065</td>
      <td>0.002991</td>
      <td>0.151001</td>
      <td>0.114126</td>
      <td>1.230621</td>
      <td>0.885639</td>
    </tr>
    <tr>
      <th>min</th>
      <td>3.800000</td>
      <td>0.080000</td>
      <td>0.000000</td>
      <td>0.600000</td>
      <td>0.009000</td>
      <td>2.000000</td>
      <td>9.000000</td>
      <td>0.987110</td>
      <td>2.720000</td>
      <td>0.220000</td>
      <td>8.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.300000</td>
      <td>0.210000</td>
      <td>0.270000</td>
      <td>1.700000</td>
      <td>0.036000</td>
      <td>23.000000</td>
      <td>108.000000</td>
      <td>0.991723</td>
      <td>3.090000</td>
      <td>0.410000</td>
      <td>9.500000</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>6.800000</td>
      <td>0.260000</td>
      <td>0.320000</td>
      <td>5.200000</td>
      <td>0.043000</td>
      <td>34.000000</td>
      <td>134.000000</td>
      <td>0.993740</td>
      <td>3.180000</td>
      <td>0.470000</td>
      <td>10.400000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.300000</td>
      <td>0.320000</td>
      <td>0.390000</td>
      <td>9.900000</td>
      <td>0.050000</td>
      <td>46.000000</td>
      <td>167.000000</td>
      <td>0.996100</td>
      <td>3.280000</td>
      <td>0.550000</td>
      <td>11.400000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>14.200000</td>
      <td>1.100000</td>
      <td>1.660000</td>
      <td>65.800000</td>
      <td>0.346000</td>
      <td>289.000000</td>
      <td>440.000000</td>
      <td>1.038980</td>
      <td>3.820000</td>
      <td>1.080000</td>
      <td>14.200000</td>
      <td>9.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# The first 5
white_df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7.0</td>
      <td>0.27</td>
      <td>0.36</td>
      <td>20.7</td>
      <td>0.045</td>
      <td>45.0</td>
      <td>170.0</td>
      <td>1.0010</td>
      <td>3.00</td>
      <td>0.45</td>
      <td>8.8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6.3</td>
      <td>0.30</td>
      <td>0.34</td>
      <td>1.6</td>
      <td>0.049</td>
      <td>14.0</td>
      <td>132.0</td>
      <td>0.9940</td>
      <td>3.30</td>
      <td>0.49</td>
      <td>9.5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.1</td>
      <td>0.28</td>
      <td>0.40</td>
      <td>6.9</td>
      <td>0.050</td>
      <td>30.0</td>
      <td>97.0</td>
      <td>0.9951</td>
      <td>3.26</td>
      <td>0.44</td>
      <td>10.1</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.2</td>
      <td>0.23</td>
      <td>0.32</td>
      <td>8.5</td>
      <td>0.058</td>
      <td>47.0</td>
      <td>186.0</td>
      <td>0.9956</td>
      <td>3.19</td>
      <td>0.40</td>
      <td>9.9</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Sample of 5
white_df.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>683</th>
      <td>6.4</td>
      <td>0.27</td>
      <td>0.32</td>
      <td>4.5</td>
      <td>0.240</td>
      <td>61.0</td>
      <td>174.0</td>
      <td>0.9948</td>
      <td>3.12</td>
      <td>0.48</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>47</th>
      <td>6.2</td>
      <td>0.46</td>
      <td>0.25</td>
      <td>4.4</td>
      <td>0.066</td>
      <td>62.0</td>
      <td>207.0</td>
      <td>0.9939</td>
      <td>3.25</td>
      <td>0.52</td>
      <td>9.8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1849</th>
      <td>7.0</td>
      <td>0.24</td>
      <td>0.25</td>
      <td>1.7</td>
      <td>0.042</td>
      <td>48.0</td>
      <td>189.0</td>
      <td>0.9920</td>
      <td>3.25</td>
      <td>0.42</td>
      <td>11.4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1382</th>
      <td>6.6</td>
      <td>0.56</td>
      <td>0.16</td>
      <td>3.1</td>
      <td>0.045</td>
      <td>28.0</td>
      <td>92.0</td>
      <td>0.9940</td>
      <td>3.12</td>
      <td>0.35</td>
      <td>9.1</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4556</th>
      <td>6.1</td>
      <td>0.20</td>
      <td>0.40</td>
      <td>1.9</td>
      <td>0.028</td>
      <td>32.0</td>
      <td>138.0</td>
      <td>0.9914</td>
      <td>3.26</td>
      <td>0.72</td>
      <td>11.7</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>



## 3) Cleaning


```python
# Checking NaN for red wine
red_df.isna().sum()
```




    fixed acidity           0
    volatile acidity        0
    citric acid             0
    residual sugar          0
    chlorides               0
    free sulfur dioxide     0
    total sulfur dioxide    0
    density                 0
    pH                      0
    sulphates               0
    alcohol                 0
    quality                 0
    dtype: int64




```python
# Checking NaN for white wine
white_df.isna().sum()
```




    fixed acidity           0
    volatile acidity        0
    citric acid             0
    residual sugar          0
    chlorides               0
    free sulfur dioxide     0
    total sulfur dioxide    0
    density                 0
    pH                      0
    sulphates               0
    alcohol                 0
    quality                 0
    dtype: int64




```python
#Checking duplicates for red wine
red_df.duplicated().sum()
```




    np.int64(240)




```python
#Removing the 240 duplicates from red wine
red_df.drop_duplicates(inplace = True)
```


```python
#Checking duplicates for red wine again
red_df.duplicated().sum()
```




    np.int64(0)




```python
#Checking duplicates for white wine
white_df.duplicated().sum()
```




    np.int64(937)




```python
#Removing the 937 duplicates from white wine
white_df.drop_duplicates(inplace = True)
```


```python
#Checking duplicates for white wine again
white_df.duplicated().sum()
```




    np.int64(0)



## 4+5) Merging


```python
# Making a "type" column in both sets to see the difference when we merge them
red_df["type"] = 1
```


```python
white_df["type"] = 2
```


```python
# Merging them together via. concat because they have the same row names.
mergedwine = pd.concat([red_df, white_df], axis=0)
```


```python
mergedwine.info()
```

    <class 'pandas.DataFrame'>
    Index: 5320 entries, 0 to 4897
    Data columns (total 13 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   fixed acidity         5320 non-null   float64
     1   volatile acidity      5320 non-null   float64
     2   citric acid           5320 non-null   float64
     3   residual sugar        5320 non-null   float64
     4   chlorides             5320 non-null   float64
     5   free sulfur dioxide   5320 non-null   float64
     6   total sulfur dioxide  5320 non-null   float64
     7   density               5320 non-null   float64
     8   pH                    5320 non-null   float64
     9   sulphates             5320 non-null   float64
     10  alcohol               5320 non-null   float64
     11  quality               5320 non-null   int64  
     12  type                  5320 non-null   int64  
    dtypes: float64(11), int64(2)
    memory usage: 581.9 KB
    


```python
#Checking 5 randoms from the merged dataframe
mergedwine.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3962</th>
      <td>7.2</td>
      <td>0.580</td>
      <td>0.27</td>
      <td>5.8</td>
      <td>0.032</td>
      <td>40.0</td>
      <td>118.0</td>
      <td>0.99088</td>
      <td>3.17</td>
      <td>0.53</td>
      <td>13.0</td>
      <td>7</td>
      <td>2</td>
    </tr>
    <tr>
      <th>237</th>
      <td>7.2</td>
      <td>0.645</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.097</td>
      <td>15.0</td>
      <td>39.0</td>
      <td>0.99675</td>
      <td>3.37</td>
      <td>0.58</td>
      <td>9.2</td>
      <td>6</td>
      <td>1</td>
    </tr>
    <tr>
      <th>136</th>
      <td>8.3</td>
      <td>0.715</td>
      <td>0.15</td>
      <td>1.8</td>
      <td>0.089</td>
      <td>10.0</td>
      <td>52.0</td>
      <td>0.99680</td>
      <td>3.23</td>
      <td>0.77</td>
      <td>9.5</td>
      <td>5</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1673</th>
      <td>6.6</td>
      <td>0.270</td>
      <td>0.31</td>
      <td>5.3</td>
      <td>0.137</td>
      <td>35.0</td>
      <td>163.0</td>
      <td>0.99510</td>
      <td>3.20</td>
      <td>0.38</td>
      <td>9.3</td>
      <td>5</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3944</th>
      <td>6.1</td>
      <td>0.270</td>
      <td>0.32</td>
      <td>6.2</td>
      <td>0.048</td>
      <td>47.0</td>
      <td>161.0</td>
      <td>0.99281</td>
      <td>3.22</td>
      <td>0.60</td>
      <td>11.0</td>
      <td>6</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



## 6) The attributes are independent so we want to make an attribute that depends on quality in the merged set


```python
# Making a dependant row for quality with category
labels=["Low", "Medium", "High"]
bins=[0, 3, 6, np.inf]
mergedwine["quality_level"] = mergedwine["quality"]
mergedwine["quality_level"] = pd.cut(mergedwine["quality_level"], labels=labels, bins=bins)
```


```python
#Checking the sum for each quality level
mergedwine["quality_level"].value_counts()
```




    quality_level
    Medium    4281
    High      1009
    Low         30
    Name: count, dtype: int64



## 7+8) Data exploration, measures and handling outliers


```python
#We use describe() to look at the mean(), quartiles, standard deviation and range
```


```python
# Red wine describes: (Example: We can see the mean of alcohol is 10.4)
red_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.000000</td>
      <td>1359.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>8.310596</td>
      <td>0.529478</td>
      <td>0.272333</td>
      <td>2.523400</td>
      <td>0.088124</td>
      <td>15.893304</td>
      <td>46.825975</td>
      <td>0.996709</td>
      <td>3.309787</td>
      <td>0.658705</td>
      <td>10.432315</td>
      <td>5.623252</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.736990</td>
      <td>0.183031</td>
      <td>0.195537</td>
      <td>1.352314</td>
      <td>0.049377</td>
      <td>10.447270</td>
      <td>33.408946</td>
      <td>0.001869</td>
      <td>0.155036</td>
      <td>0.170667</td>
      <td>1.082065</td>
      <td>0.823578</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>4.600000</td>
      <td>0.120000</td>
      <td>0.000000</td>
      <td>0.900000</td>
      <td>0.012000</td>
      <td>1.000000</td>
      <td>6.000000</td>
      <td>0.990070</td>
      <td>2.740000</td>
      <td>0.330000</td>
      <td>8.400000</td>
      <td>3.000000</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>7.100000</td>
      <td>0.390000</td>
      <td>0.090000</td>
      <td>1.900000</td>
      <td>0.070000</td>
      <td>7.000000</td>
      <td>22.000000</td>
      <td>0.995600</td>
      <td>3.210000</td>
      <td>0.550000</td>
      <td>9.500000</td>
      <td>5.000000</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7.900000</td>
      <td>0.520000</td>
      <td>0.260000</td>
      <td>2.200000</td>
      <td>0.079000</td>
      <td>14.000000</td>
      <td>38.000000</td>
      <td>0.996700</td>
      <td>3.310000</td>
      <td>0.620000</td>
      <td>10.200000</td>
      <td>6.000000</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>9.200000</td>
      <td>0.640000</td>
      <td>0.430000</td>
      <td>2.600000</td>
      <td>0.091000</td>
      <td>21.000000</td>
      <td>63.000000</td>
      <td>0.997820</td>
      <td>3.400000</td>
      <td>0.730000</td>
      <td>11.100000</td>
      <td>6.000000</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>15.900000</td>
      <td>1.580000</td>
      <td>1.000000</td>
      <td>15.500000</td>
      <td>0.611000</td>
      <td>72.000000</td>
      <td>289.000000</td>
      <td>1.003690</td>
      <td>4.010000</td>
      <td>2.000000</td>
      <td>14.900000</td>
      <td>8.000000</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#White wine describes: (Example we can se the mean of alcohol is 10.6)
white_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.000000</td>
      <td>3961.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>6.839346</td>
      <td>0.280538</td>
      <td>0.334332</td>
      <td>5.914819</td>
      <td>0.045905</td>
      <td>34.889169</td>
      <td>137.193512</td>
      <td>0.993790</td>
      <td>3.195458</td>
      <td>0.490351</td>
      <td>10.589358</td>
      <td>5.854835</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.866860</td>
      <td>0.103437</td>
      <td>0.122446</td>
      <td>4.861646</td>
      <td>0.023103</td>
      <td>17.210021</td>
      <td>43.129065</td>
      <td>0.002905</td>
      <td>0.151546</td>
      <td>0.113523</td>
      <td>1.217076</td>
      <td>0.890683</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>3.800000</td>
      <td>0.080000</td>
      <td>0.000000</td>
      <td>0.600000</td>
      <td>0.009000</td>
      <td>2.000000</td>
      <td>9.000000</td>
      <td>0.987110</td>
      <td>2.720000</td>
      <td>0.220000</td>
      <td>8.000000</td>
      <td>3.000000</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.300000</td>
      <td>0.210000</td>
      <td>0.270000</td>
      <td>1.600000</td>
      <td>0.035000</td>
      <td>23.000000</td>
      <td>106.000000</td>
      <td>0.991620</td>
      <td>3.090000</td>
      <td>0.410000</td>
      <td>9.500000</td>
      <td>5.000000</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>6.800000</td>
      <td>0.260000</td>
      <td>0.320000</td>
      <td>4.700000</td>
      <td>0.042000</td>
      <td>33.000000</td>
      <td>133.000000</td>
      <td>0.993500</td>
      <td>3.180000</td>
      <td>0.480000</td>
      <td>10.400000</td>
      <td>6.000000</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.300000</td>
      <td>0.330000</td>
      <td>0.390000</td>
      <td>8.900000</td>
      <td>0.050000</td>
      <td>45.000000</td>
      <td>166.000000</td>
      <td>0.995710</td>
      <td>3.290000</td>
      <td>0.550000</td>
      <td>11.400000</td>
      <td>6.000000</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>14.200000</td>
      <td>1.100000</td>
      <td>1.660000</td>
      <td>65.800000</td>
      <td>0.346000</td>
      <td>289.000000</td>
      <td>440.000000</td>
      <td>1.038980</td>
      <td>3.820000</td>
      <td>1.080000</td>
      <td>14.200000</td>
      <td>9.000000</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Combined descriptive statistics of the wines (Example we can see the mean of the alcohol is 10.5)
mergedwine.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>7.215179</td>
      <td>0.344130</td>
      <td>0.318494</td>
      <td>5.048477</td>
      <td>0.056690</td>
      <td>30.036654</td>
      <td>114.109023</td>
      <td>0.994535</td>
      <td>3.224664</td>
      <td>0.533357</td>
      <td>10.549241</td>
      <td>5.795677</td>
      <td>1.744549</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.319671</td>
      <td>0.168248</td>
      <td>0.147157</td>
      <td>4.500180</td>
      <td>0.036863</td>
      <td>17.805045</td>
      <td>56.774223</td>
      <td>0.002966</td>
      <td>0.160379</td>
      <td>0.149743</td>
      <td>1.185933</td>
      <td>0.879772</td>
      <td>0.436155</td>
    </tr>
    <tr>
      <th>min</th>
      <td>3.800000</td>
      <td>0.080000</td>
      <td>0.000000</td>
      <td>0.600000</td>
      <td>0.009000</td>
      <td>1.000000</td>
      <td>6.000000</td>
      <td>0.987110</td>
      <td>2.720000</td>
      <td>0.220000</td>
      <td>8.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.400000</td>
      <td>0.230000</td>
      <td>0.240000</td>
      <td>1.800000</td>
      <td>0.038000</td>
      <td>16.000000</td>
      <td>74.000000</td>
      <td>0.992200</td>
      <td>3.110000</td>
      <td>0.430000</td>
      <td>9.500000</td>
      <td>5.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7.000000</td>
      <td>0.300000</td>
      <td>0.310000</td>
      <td>2.700000</td>
      <td>0.047000</td>
      <td>28.000000</td>
      <td>116.000000</td>
      <td>0.994650</td>
      <td>3.210000</td>
      <td>0.510000</td>
      <td>10.400000</td>
      <td>6.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.700000</td>
      <td>0.410000</td>
      <td>0.400000</td>
      <td>7.500000</td>
      <td>0.066000</td>
      <td>41.000000</td>
      <td>153.250000</td>
      <td>0.996770</td>
      <td>3.330000</td>
      <td>0.600000</td>
      <td>11.400000</td>
      <td>6.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>15.900000</td>
      <td>1.580000</td>
      <td>1.660000</td>
      <td>65.800000</td>
      <td>0.611000</td>
      <td>289.000000</td>
      <td>440.000000</td>
      <td>1.038980</td>
      <td>4.010000</td>
      <td>2.000000</td>
      <td>14.900000</td>
      <td>9.000000</td>
      <td>2.000000</td>
    </tr>
  </tbody>
</table>
</div>



### Check about attributes are normally distributed


```python
#Histogram to of alcohol in red dataframe - right skewed (positive skewed)
red_df['alcohol'].plot.hist(bins=30, title='Alcohol distribution - Red wine')
```




    <Axes: title={'center': 'Alcohol distribution - Red wine'}, ylabel='Frequency'>




    
![png](output_40_1.png)
    



```python
red_df["alcohol"].skew()
```




    np.float64(0.8598411692032926)




```python
# It has more deviation than red histogram, the most frequent value isnt as dominant as in red histogram.
white_df['alcohol'].plot.hist(title='Alcohol distribution - White wine')
```




    <Axes: title={'center': 'Alcohol distribution - White wine'}, ylabel='Frequency'>




    
![png](output_42_1.png)
    



```python
mergedwine['alcohol'].plot.hist(title='Alcohol distribution | White- and red wine')
```




    <Axes: title={'center': 'Alcohol distribution | White- and red wine'}, ylabel='Frequency'>




    
![png](output_43_1.png)
    


### Comparing distributions in the merged dataset


```python
#Boxplot by alcohol and type of wine. You can see we have some outliers in type 1 aka red wine
#because they are outside the whiskers.
mergedwine.boxplot(column='alcohol', by='type')
```




    <Axes: title={'center': 'alcohol'}, xlabel='type'>




    
![png](output_45_1.png)
    



```python
mergedwine.boxplot(column='quality', by='type')
```




    <Axes: title={'center': 'quality'}, xlabel='type'>




    
![png](output_46_1.png)
    


### Comparing discriptive statistics in the merged dataset


```python
mergedwine.groupby('type')['alcohol'].describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
    <tr>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1359.0</td>
      <td>10.432315</td>
      <td>1.082065</td>
      <td>8.4</td>
      <td>9.5</td>
      <td>10.2</td>
      <td>11.1</td>
      <td>14.9</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3961.0</td>
      <td>10.589358</td>
      <td>1.217076</td>
      <td>8.0</td>
      <td>9.5</td>
      <td>10.4</td>
      <td>11.4</td>
      <td>14.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
mergedwine.groupby('type')['quality'].describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
    <tr>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1359.0</td>
      <td>5.623252</td>
      <td>0.823578</td>
      <td>3.0</td>
      <td>5.0</td>
      <td>6.0</td>
      <td>6.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3961.0</td>
      <td>5.854835</td>
      <td>0.890683</td>
      <td>3.0</td>
      <td>5.0</td>
      <td>6.0</td>
      <td>6.0</td>
      <td>9.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#We can see a huge outlier for residual sugar in white wine
mergedwine.boxplot(column="residual sugar", by="type")
```




    <Axes: title={'center': 'residual sugar'}, xlabel='type'>




    
![png](output_50_1.png)
    


### Removing outliers


```python
# Looking for outliers: (Q3 -Q1) * 1.5 
#outliers by inter-quartile range (IQR)
from typing import List
def remove_outliers(df, data: List, factor):
    q1 = df[data].quantile(.25)
    q3 = df[data].quantile(.75)
    IQR = q3 - q1
    # values smaller than 1.5 IQR below q1 and bigger than 1.5 IQR over q3
    outliers = df[(df[data] < (q1 - factor * IQR)) | (df[data] > (q3 + factor * IQR))]
    df = df.drop(outliers.index)
    return df
```


```python
#Using IQR to remove outliers
redsub = remove_outliers(red_df, "alcohol", factor=1.5)
```


```python
# Removing the outliers to see if it made an impact
redsub["alcohol"].plot.hist(bins=30)
```




    <Axes: ylabel='Frequency'>




    
![png](output_54_1.png)
    



```python
#Becuase removing outliers didnt make such an impact we will try to log it to see if it changes the distrubution
redsub["alcohol_log"] = np.log(redsub["alcohol"])
redsub["alcohol_log"].plot.hist(bins=30)
```




    <Axes: ylabel='Frequency'>




    
![png](output_55_1.png)
    


##### There is not a normal distrubution in alcohol because most of the values is around 9 and when we remove the outliers most of the values still is around 9 so when we use the log function there shouldnt be much of a difference when we look at distrubution. Example the numbers is still going to be placed at 2.2-2.3


```python
red_df["alcohol"].skew()
```




    np.float64(0.8598411692032926)




```python
redsub["alcohol"].skew()
```




    np.float64(0.7320876355355268)




```python
# Checking the mean before removing outliers for red- and white wine
mergedwine.groupby("type")["alcohol"].mean()
```




    type
    1    10.432315
    2    10.589358
    Name: alcohol, dtype: float64




```python
# The mean after removing outliers from red wine
redsub["alcohol"].mean()
```




    np.float64(10.401373422420194)



#### By removing the outliers the value of skew comes closer to 0
#### There weren't any outliers in white wine therefore we didnt remove any


```python
red_df["alcohol"].kurt()
```




    np.float64(0.1597388547368781)




```python
redsub["alcohol"].kurt()
```




    np.float64(-0.3256463820420339)



#### By removing the outliers we can see the Kurtosis value became negative therefore meaning no extreme outliers

## 9) Differences and similarities


```python
mergedwine[mergedwine['type']==1]['quality'].plot.hist(title='Quality distribution')
```




    <Axes: title={'center': 'Quality distribution'}, ylabel='Frequency'>




    
![png](output_66_1.png)
    



```python
mergedwine[mergedwine['type']==2]['quality'].plot.hist(title='Quality distribution')
```




    <Axes: title={'center': 'Quality distribution'}, ylabel='Frequency'>




    
![png](output_67_1.png)
    


#### Diagrammerne viser en tydelig spredning


```python
mergedwine.boxplot(column='quality', by='type')
```




    <Axes: title={'center': 'quality'}, xlabel='type'>




    
![png](output_69_1.png)
    



```python
#### Shows the outliers clear like the diagrams above. The centering is at 5 & 6.
#### The green line shows the median

mergedwine.boxplot(column='alcohol', by='type')
```




    <Axes: title={'center': 'alcohol'}, xlabel='type'>




    
![png](output_70_1.png)
    


#### Showing outliers again, the median and the difference of  alcohol % in red and white.


```python
mergedwine.boxplot(column='free sulfur dioxide', by='type')
```




    <Axes: title={'center': 'free sulfur dioxide'}, xlabel='type'>




    
![png](output_72_1.png)
    


#### Very different than the other diagrams, here you can see the outliers clearly on both sides
#### The amount of 'free sulfur dioxide' show a big "std" compared to eachother

### b. which wine has higher average quality?


```python
mergedwine.groupby('type')['quality'].mean()
```




    type
    1    5.623252
    2    5.854835
    Name: quality, dtype: float64



#### Red wine average quality = 5,623252
#### White wine average quality = 5,854835 (winner)

### c. which type of wine has higher average level of alcohol?


```python
mergedwine.groupby('type')['alcohol'].mean()
```




    type
    1    10.432315
    2    10.589358
    Name: alcohol, dtype: float64



#### Red wine average alcohol = 10,432315
#### White wine average alcohol = 10,589358 (winner)

#### d. which one has higher average quantity of residual sugar?


```python
mergedwine.groupby('type')['residual sugar'].mean()
```




    type
    1    2.523400
    2    5.914819
    Name: residual sugar, dtype: float64




```python
mergedwine_no_extreme_outlier = mergedwine[(mergedwine["residual sugar"] < 64)]
```


```python
mergedwine_no_extreme_outlier.groupby("type")["residual sugar"].mean()
```




    type
    1    2.523400
    2    5.899697
    Name: residual sugar, dtype: float64



##### We removed the one EXTREME outlier by hardcoding it

#### Red wine average residual sugar = 2,523400
#### White wine average residual sugar = 5.899697

#### e. do the quantity of alcohol and residual sugar influence the quality of the wine?


```python
mergedwine[['alcohol','quality']].corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>alcohol</th>
      <td>1.000000</td>
      <td>0.469422</td>
    </tr>
    <tr>
      <th>quality</th>
      <td>0.469422</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



##### #0.469422 positiv sammenhæng men ikke klokkeklart


```python
mergedwine[['residual sugar','quality']].corr() 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>residual sugar</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>residual sugar</th>
      <td>1.00000</td>
      <td>-0.05683</td>
    </tr>
    <tr>
      <th>quality</th>
      <td>-0.05683</td>
      <td>1.00000</td>
    </tr>
  </tbody>
</table>
</div>



##### -0.05683 negativ sammenhæng dvs ingen sammenhæng


```python
red_df[['alcohol','quality']].corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>alcohol</th>
      <td>1.000000</td>
      <td>0.480343</td>
    </tr>
    <tr>
      <th>quality</th>
      <td>0.480343</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



##### o.480343 positiv sammenhæng men slet ikke klokkeklart


```python
white_df[['residual sugar','quality']].corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>residual sugar</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>residual sugar</th>
      <td>1.000000</td>
      <td>-0.117339</td>
    </tr>
    <tr>
      <th>quality</th>
      <td>-0.117339</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



##### -0.117339 negativ sammenhæng, altså slet ikke noget

##### Konklusion er at ingen af dem er særlig tæt på 1, så der er ikke nogen klokkeklar sammenhæng

# 10

### Making 5 bins


```python
mergedwine["pH_bin_5"] = pd.cut(mergedwine["pH"], bins=10)
mergedwine["pH_bin_5"]
```




    0       (3.494, 3.623]
    1       (3.107, 3.236]
    2       (3.236, 3.365]
    3       (3.107, 3.236]
    5       (3.494, 3.623]
                 ...      
    4893    (3.236, 3.365]
    4894    (3.107, 3.236]
    4895    (2.978, 3.107]
    4896    (3.236, 3.365]
    4897    (3.236, 3.365]
    Name: pH_bin_5, Length: 5320, dtype: category
    Categories (10, interval[float64, right]): [(2.719, 2.849] < (2.849, 2.978] < (2.978, 3.107] < (3.107, 3.236] ... (3.494, 3.623] < (3.623, 3.752] < (3.752, 3.881] < (3.881, 4.01]]



##### Count the amount in every bin 



```python
density_5 = mergedwine["pH_bin_5"].value_counts().sort_index()
density_5
```




    pH_bin_5
    (2.719, 2.849]      14
    (2.849, 2.978]     239
    (2.978, 3.107]     969
    (3.107, 3.236]    1718
    (3.236, 3.365]    1403
    (3.365, 3.494]     686
    (3.494, 3.623]     228
    (3.623, 3.752]      47
    (3.752, 3.881]      12
    (3.881, 4.01]        4
    Name: count, dtype: int64



##### Det giver et overblik over spredningen af ph-værdierne fra lavest til høj og hvor centreringen ligger

# 11)

##### Vin producenter kunne være interesserede i hvad der påvirker hinanden, som f.eks:
##### alkohol vs kvalitet
##### ph vs kvalitet
##### Forburgere kunne være interesserede i om mere alkohol betyder højere kvalitet?
##### eller residual sugar vs kvalitet?

# 12+13) Correlation + heatmap


```python
# Correlation
# We use Pearson correlation function for numeric values of two sets, each with normal distribution.
corr1 = stats.pearsonr(mergedwine["residual sugar"], mergedwine["alcohol"])
corr1 
#corr 1 between residual sugar and alcohol has correlation but it is not strong
```




    PearsonRResult(statistic=np.float64(-0.3052420355899367), pvalue=np.float64(4.087748791205293e-115))




```python
# correrlation matrix
# We need to remove our quality_level because it is a category, then we look at all the r values to see correlation 
# between the attributes
num_cols = mergedwine.select_dtypes(include="number")
cmat = num_cols.corr()
cmat
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>fixed acidity</th>
      <td>1.000000</td>
      <td>0.214752</td>
      <td>0.330328</td>
      <td>-0.104439</td>
      <td>0.288918</td>
      <td>-0.281590</td>
      <td>-0.327471</td>
      <td>0.478180</td>
      <td>-0.271182</td>
      <td>0.304844</td>
      <td>-0.102573</td>
      <td>-0.080092</td>
      <td>-0.486253</td>
    </tr>
    <tr>
      <th>volatile acidity</th>
      <td>0.214752</td>
      <td>1.000000</td>
      <td>-0.384192</td>
      <td>-0.163696</td>
      <td>0.367626</td>
      <td>-0.349039</td>
      <td>-0.400716</td>
      <td>0.308452</td>
      <td>0.246687</td>
      <td>0.227772</td>
      <td>-0.065411</td>
      <td>-0.265205</td>
      <td>-0.645335</td>
    </tr>
    <tr>
      <th>citric acid</th>
      <td>0.330328</td>
      <td>-0.384192</td>
      <td>1.000000</td>
      <td>0.146189</td>
      <td>0.055199</td>
      <td>0.130849</td>
      <td>0.194835</td>
      <td>0.094758</td>
      <td>-0.344735</td>
      <td>0.059183</td>
      <td>-0.005496</td>
      <td>0.097954</td>
      <td>0.183759</td>
    </tr>
    <tr>
      <th>residual sugar</th>
      <td>-0.104439</td>
      <td>-0.163696</td>
      <td>0.146189</td>
      <td>1.000000</td>
      <td>-0.123094</td>
      <td>0.398717</td>
      <td>0.487519</td>
      <td>0.520930</td>
      <td>-0.234522</td>
      <td>-0.174717</td>
      <td>-0.305242</td>
      <td>-0.056830</td>
      <td>0.328695</td>
    </tr>
    <tr>
      <th>chlorides</th>
      <td>0.288918</td>
      <td>0.367626</td>
      <td>0.055199</td>
      <td>-0.123094</td>
      <td>1.000000</td>
      <td>-0.186615</td>
      <td>-0.269817</td>
      <td>0.371867</td>
      <td>0.025823</td>
      <td>0.405051</td>
      <td>-0.269601</td>
      <td>-0.202137</td>
      <td>-0.499517</td>
    </tr>
    <tr>
      <th>free sulfur dioxide</th>
      <td>-0.281590</td>
      <td>-0.349039</td>
      <td>0.130849</td>
      <td>0.398717</td>
      <td>-0.186615</td>
      <td>1.000000</td>
      <td>0.720488</td>
      <td>0.006166</td>
      <td>-0.141747</td>
      <td>-0.198244</td>
      <td>-0.170012</td>
      <td>0.054002</td>
      <td>0.465326</td>
    </tr>
    <tr>
      <th>total sulfur dioxide</th>
      <td>-0.327471</td>
      <td>-0.400716</td>
      <td>0.194835</td>
      <td>0.487519</td>
      <td>-0.269817</td>
      <td>0.720488</td>
      <td>1.000000</td>
      <td>0.006711</td>
      <td>-0.222956</td>
      <td>-0.275836</td>
      <td>-0.249004</td>
      <td>-0.050296</td>
      <td>0.694229</td>
    </tr>
    <tr>
      <th>density</th>
      <td>0.478180</td>
      <td>0.308452</td>
      <td>0.094758</td>
      <td>0.520930</td>
      <td>0.371867</td>
      <td>0.006166</td>
      <td>0.006711</td>
      <td>1.000000</td>
      <td>0.034273</td>
      <td>0.282690</td>
      <td>-0.667811</td>
      <td>-0.326434</td>
      <td>-0.429377</td>
    </tr>
    <tr>
      <th>pH</th>
      <td>-0.271182</td>
      <td>0.246687</td>
      <td>-0.344735</td>
      <td>-0.234522</td>
      <td>0.025823</td>
      <td>-0.141747</td>
      <td>-0.222956</td>
      <td>0.034273</td>
      <td>1.000000</td>
      <td>0.168150</td>
      <td>0.097314</td>
      <td>0.039733</td>
      <td>-0.310919</td>
    </tr>
    <tr>
      <th>sulphates</th>
      <td>0.304844</td>
      <td>0.227772</td>
      <td>0.059183</td>
      <td>-0.174717</td>
      <td>0.405051</td>
      <td>-0.198244</td>
      <td>-0.275836</td>
      <td>0.282690</td>
      <td>0.168150</td>
      <td>1.000000</td>
      <td>-0.017232</td>
      <td>0.041884</td>
      <td>-0.490364</td>
    </tr>
    <tr>
      <th>alcohol</th>
      <td>-0.102573</td>
      <td>-0.065411</td>
      <td>-0.005496</td>
      <td>-0.305242</td>
      <td>-0.269601</td>
      <td>-0.170012</td>
      <td>-0.249004</td>
      <td>-0.667811</td>
      <td>0.097314</td>
      <td>-0.017232</td>
      <td>1.000000</td>
      <td>0.469422</td>
      <td>0.057756</td>
    </tr>
    <tr>
      <th>quality</th>
      <td>-0.080092</td>
      <td>-0.265205</td>
      <td>0.097954</td>
      <td>-0.056830</td>
      <td>-0.202137</td>
      <td>0.054002</td>
      <td>-0.050296</td>
      <td>-0.326434</td>
      <td>0.039733</td>
      <td>0.041884</td>
      <td>0.469422</td>
      <td>1.000000</td>
      <td>0.114809</td>
    </tr>
    <tr>
      <th>type</th>
      <td>-0.486253</td>
      <td>-0.645335</td>
      <td>0.183759</td>
      <td>0.328695</td>
      <td>-0.499517</td>
      <td>0.465326</td>
      <td>0.694229</td>
      <td>-0.429377</td>
      <td>-0.310919</td>
      <td>-0.490364</td>
      <td>0.057756</td>
      <td>0.114809</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Making a heatmap using seaborn import. We are using the correlation matrix "cmat" 
sbn.heatmap(cmat, cmap="YlGnBu", annot=False, vmin=-1, vmax=1)
```




    <Axes: >




    
![png](output_107_1.png)
    


On the heatmap we can observe many correlations such as:

#### Mid to high correlation:
* Alchohol and density (negative correlation -0.75).
* Fixed acidity and density (0.50).
* Residual sugar and density (0.50).
* Free sulfur dioxide and total sulfur dioxide (0.80)
* Type and total sulphur dioxide (0.75)

#### Highest and lowest correlation to wine quality:
* Lowest correlation by observations of the heatmap: citric acide, pH and total sulphur dioxide
* Higest correlation by observations of the heatmap: Alcohol and density


```python
# We can test our observations by using Pearsons function

#Quality and alcohol
corr_qual_alc = stats.pearsonr(mergedwine["quality"], mergedwine["alcohol"])
corr_qual_alc
#The shown result 0.46 means is has a moderate correlation and the pvalue means the significance evidence 
# of the the correlation is really strong because our pvalue < 0.01 and usually we check for 0.05.
```




    PearsonRResult(statistic=np.float64(0.4694218379411509), pvalue=np.float64(8.284910921622735e-290))



# 14) Min max scaling 

We transform data to a fixed range (0, 1).
x = (x-xmin)/(xmax-xmin)


```python
# Function for min max. Find the lowest and higest value.  substract data from min value and divideo with max-min
def minmax(data):
    min_val = np.min(data)
    max_val = np.max(data)
    scaled_data = (data - min_val) / (max_val - min_val)
    return scaled_data
```


```python
 # Taking our num_cols from the previous pearson function because it only operates on numbers
mergedminmax = num_cols.apply(minmax)
mergedminmax.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
      <td>5320.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>0.282246</td>
      <td>0.176086</td>
      <td>0.191864</td>
      <td>0.068228</td>
      <td>0.079219</td>
      <td>0.100822</td>
      <td>0.249099</td>
      <td>0.143152</td>
      <td>0.391212</td>
      <td>0.176043</td>
      <td>0.369455</td>
      <td>0.465946</td>
      <td>0.744549</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.109064</td>
      <td>0.112166</td>
      <td>0.088649</td>
      <td>0.069021</td>
      <td>0.061235</td>
      <td>0.061823</td>
      <td>0.130816</td>
      <td>0.057172</td>
      <td>0.124325</td>
      <td>0.084125</td>
      <td>0.171874</td>
      <td>0.146629</td>
      <td>0.436155</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.214876</td>
      <td>0.100000</td>
      <td>0.144578</td>
      <td>0.018405</td>
      <td>0.048173</td>
      <td>0.052083</td>
      <td>0.156682</td>
      <td>0.098130</td>
      <td>0.302326</td>
      <td>0.117978</td>
      <td>0.217391</td>
      <td>0.333333</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>0.264463</td>
      <td>0.146667</td>
      <td>0.186747</td>
      <td>0.032209</td>
      <td>0.063123</td>
      <td>0.093750</td>
      <td>0.253456</td>
      <td>0.145363</td>
      <td>0.379845</td>
      <td>0.162921</td>
      <td>0.347826</td>
      <td>0.500000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>0.322314</td>
      <td>0.220000</td>
      <td>0.240964</td>
      <td>0.105828</td>
      <td>0.094684</td>
      <td>0.138889</td>
      <td>0.339286</td>
      <td>0.186235</td>
      <td>0.472868</td>
      <td>0.213483</td>
      <td>0.492754</td>
      <td>0.500000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



#### The attributes are now in the interval between 0 and 1. We can observe most of the mean values are closer to the min. The std values shows that most of the values is close to the mean. 

# 15)


```python
from scipy.stats import ttest_ind

red_alcohol = mergedwine[mergedwine['type'] == 1]['alcohol']
white_alcohol = mergedwine[mergedwine['type'] == 2]['alcohol']

t_stat, p_value = ttest_ind(red_alcohol, white_alcohol)

print("T-statistic:", t_stat)
print("P-value:", p_value)

alpha = 0.05

if p_value < alpha:
    print("Reject H0: Alcohol means are significantly different.")
else:
    print("Fail to reject H0.")
```

    T-statistic: -4.218888835968011
    P-value: 2.4959339763303842e-05
    Reject H0: Alcohol means are significantly different.
    

# 16 ) Conclusion

Summarise and reflect on your experience. Have the results met your expectations? Have you
managed to prove your initial hypotheses? Which are your main conclusions about wine, derived
from this data, which of them could be shared with the related businesses? 

## Hypothesis and expectations

We expected that red wine had a higher alcohol average and expected that H1 would be correct.

* H0 = Our hypothesis is the alcohol average for red and white wine are the same.
* H1 = Alternative hypothesis is one wine has a higher alcohol average.

From our previous t-test results we rejected H0 and therefore leaving us with H1 because the alcohol mean between red and white are significantly different. The alcohol average between red and white are close but not exactly the same.

We used some statistical functions and saw white wine has over double the residual sugar average compared to red wine. We compared red and white alcohol average and white had around 0.1 more in their average value. The biggest count of ph values when making bins are at the interval: 3.1-3.2. 

When using pearson correlation and a heatmap we observed that denisty was an attribute that stood out. Density had 3+ attributes with a mid/high correlation. 
We also observed that quality and alcohol has a moderate correlation.

We plotted histograms and saw normal distrubutions but with a positive skew for red- and white wine compared to alcohol. When boxplotting we observed outliers in red wine+alcohol and an extreme outlier in residual sugar+white wine.

We used methods to create normal distrubution without skew, like np.log() but it didnt make an impact. We tried min-maxing with a fixed range so the value is in the interval between 0-1. We observed almost every value was closer to min than max.

Suggestion to another company in terms of alcohol vs quality:
In relation to what we can conclude business wise for win distrubitors, then we can see that alcohol has en impact on the quality level of the wine.  In this code example: wine_df[['alcohol','quality']].corr() 0.469422 positive  we have calculated that the correlation is  0.469422 which means that we can not conclude that 100%, but it tells us that if you want some quality in your whine, you don't go for 2% alcohol. But it need some percentages

We could've changed our h1 and h0 to the alcohol not being exact the same, but in a certain range of each other, but it first occured to us on the last day when we were to write the conclusion. It would have made more sense maybe, but we have reached the goal by coming to the conclusion that we reject h0 because of the statisticly significance.
